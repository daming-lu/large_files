The tutorials in v1_api_tutorials are using v1_api currently, and will be upgraded to v2_api later.
Thus, v1_api_tutorials is a temporary directory. We decide not to maintain it and will delete it in future.

Please go to [PaddlePaddle/book](https://github.com/PaddlePaddle/book) and 
[PaddlePaddle/models](https://github.com/PaddlePaddle/models) to learn PaddlePaddle.
