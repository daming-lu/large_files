To build PaddlePaddle data preparation image in tutorial [Distributed PaddlePaddle Training on AWS with Kubernetes](../../k8s_aws_en.md), run following commands:

```
cp -r ../../../../../../demo/quick_start .
docker build . -t prepare-data-image-name
```
